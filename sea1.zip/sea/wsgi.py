from app import app  # Ensure 'app' is your Flask app instance

if __name__ == "__main__":
    app.run()  # For local testing; not required in production


